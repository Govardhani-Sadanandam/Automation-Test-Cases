﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;

namespace Automation.TestCases
{

    class TestCase6
    {
        private static readonly string item = "Arrange Shelf";
        private static readonly string secondItem = "Wash Clothes";

        [Test]
        [Description("Complete All Active To-Dos")]
        public void TestCase6_Test()
        {
            IWebDriver driver = new FirefoxDriver(); //Start the browser
            driver.Url = "http://todomvc.com"; //open the Application
            driver.FindElement(By.LinkText("AngularJS")).Click();// Click on AngularJS Link 
            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(5)); //Wait for Page Elements to Load Completely
            driver.FindElement(By.XPath(".//form[@id='todo-form']/input[@id='new-todo']")).SendKeys(item); //Add a item to To Do list
            driver.FindElement(By.XPath(".//form[@id='todo-form']/input[@id='new-todo']")).SendKeys(Keys.Enter);
            driver.FindElement(By.XPath(".//form[@id='todo-form']/input[@id='new-todo']")).SendKeys(secondItem); //Add Second item to To Do list
            driver.FindElement(By.XPath(".//form[@id='todo-form']/input[@id='new-todo']")).SendKeys(Keys.Enter);
            driver.FindElement(By.Id("toggle-all")).Click();
            driver.Close();
        }
    }
}
