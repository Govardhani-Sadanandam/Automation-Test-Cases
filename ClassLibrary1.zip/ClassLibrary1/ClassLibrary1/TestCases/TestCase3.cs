﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;

namespace Automation.TestCases
{
    class TestCase3
    {
        private static readonly string item = "Arrange Shelf";

        [Test]
        [Description("Complete a To-do by clicking inside the circle UI to the left of the To-do")]
        public void TestCase3_Test()
        {
            IWebDriver driver = new FirefoxDriver(); //Start the browser
            driver.Url = "http://todomvc.com"; //open the Application
            driver.FindElement(By.LinkText("AngularJS")).Click();// Click on AngularJS Link 
            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(5)); //Wait for Page Elements to Load Completely
            driver.FindElement(By.XPath(".//form[@id='todo-form']/input[@id='new-todo']")).SendKeys(item); //Add item to To Do list
            driver.FindElement(By.XPath(".//form[@id='todo-form']/input[@id='new-todo']")).SendKeys(Keys.Enter);
            driver.FindElement(By.XPath(".//ul[@id='todo-list']/li[1]/div[@class='view']/input[1]")).Click();//Click on Input Element
            driver.Close();
            ;
        }
    }
}
