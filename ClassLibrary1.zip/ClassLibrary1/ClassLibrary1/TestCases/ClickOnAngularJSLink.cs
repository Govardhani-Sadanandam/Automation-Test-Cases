﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace Automation.TestCases
{
    class ClickOnAngularJSLink
    {

        [Test]
        [Description("Click on ANGULARJS Link")]
        public void ClickOnAngularJSLink_Test()
        {
            IWebDriver driver = new FirefoxDriver(); //Start the browser
            driver.Url = "http://todomvc.com"; //open the Application
            driver.FindElement(By.LinkText("AngularJS")).Click();  // Click on AngularJS Link 
            driver.Close();  //Close the browser
        }
    }
}
