﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace Automation.TestCases
{
    class NavigateToMasterPage
    {
        [Test]
        [Description("Navigate to Main Page")]
        public void NavigateTOMasterPage_Test()
        {
            IWebDriver driver = new FirefoxDriver(); //Start the browser
            driver.Url = "http://todomvc.com"; //open the Application
            driver.Close();  //Close the browser
        }
    }
}
