﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Interactions.Internal;





namespace Automation.TestCases
{

    class TestCase2
    {
         private static readonly string item = "Arrange Shelf";

        [Test]
        [Description("Edit an item")]
        public void TestCase2_Test()
        {
            IWebDriver driver = new FirefoxDriver(); //Start the browser
            driver.Url = "http://todomvc.com"; //open the Application
            driver.FindElement(By.LinkText("AngularJS")).Click();// Click on AngularJS Link 
            driver.Manage().Timeouts().ImplicitlyWait(TimeSpan.FromSeconds(25)); //Wait for Page Elements to Load Completely
            driver.FindElement(By.XPath(".//form[@id='todo-form']/input[@id='new-todo']")).SendKeys(item); //Add item to To Do list
            driver.FindElement(By.XPath(".//form[@id='todo-form']/input[@id='new-todo']")).SendKeys(Keys.Enter);
            //Actions for Double click
            Actions action = new Actions(driver);
            IWebElement click = driver.FindElement(By.XPath(".//ul[@id='todo-list']/li[1]/div[@class='view']/label[1]"));
            action.DoubleClick(click).Build().Perform();
            driver.Close();  //Close the browser
        }
    }
}
